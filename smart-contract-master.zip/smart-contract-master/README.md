# Project Hydro
This repository has been replaced, all Hydro smart contracts are now located at:

[https://github.com/hydrogen-dev/smart-contracts](https://github.com/hydrogen-dev/smart-contracts)
